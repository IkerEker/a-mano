#!/bin/bash
# Instala «A mano AE» en After Effects (Mac). Doble clic; si macOS no deja, clic derecho > Abrir.
cd "$(dirname "$0")"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.amano.ae"
mkdir -p "$HOME/Library/Application Support/Adobe/CEP/extensions"
rm -rf "$DEST"
cp -R "com.amano.ae" "$DEST"
for v in 9 10 11 12 13; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
killall cfprefsd 2>/dev/null
echo ""
echo "Instalado en: $DEST"
echo "Cierra After Effects del todo, vuelve a abrirlo y busca el panel en"
echo "Ventana > Extensiones > A mano   (en algunas versiones: Extensiones (heredadas))."
echo ""
read -n 1 -s -r -p "Pulsa una tecla para cerrar."
