@echo off
rem Instala "A mano AE" en After Effects (Windows). Doble clic.
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.amano.ae"
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%~dp0com.amano.ae" "%DEST%\" /e /i /y /q >nul
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo.
echo Instalado en: %DEST%
echo Cierra After Effects del todo, vuelve a abrirlo y busca el panel en
echo Ventana ^> Extensiones ^> A mano   (en algunas versiones: Extensiones (heredadas)).
echo.
pause
